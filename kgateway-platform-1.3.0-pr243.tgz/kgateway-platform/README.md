# kgateway-platform

![Version: 1.3.0](https://img.shields.io/badge/Version-1.3.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square)

Helm chart for configuring the kgateway platform using the Kubernetes Gateway API
with support for multiple gateways, HTTP(S) routing, and TLS certificate integration.

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| trowaflo | <trowa.flo@gmail.com> |  |

## Source Code

* <https://github.com/kgateway-dev/kgateway>
* <https://docs.kgateway.dev/>
* <https://github.com/trowaflo/helm-charts>

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| oci://cr.kgateway.dev/kgateway-dev/charts | kgateway(kgateway) | v2.2.2 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| fullnameOverride | string | "" (unused by the current fullname helper) | Override the full name used in resource naming (reserved for helpers that support it). In this chart, the simplified kgateway-platform.fullname helper currently ignores fullnameOverride and always uses .Release.Name. This value is kept for compatibility/future use; setting it has no effect unless templates/helpers explicitly reference it.  |
| gateways | object | {} (empty, user must configure gateways) | Gateway configuration. Define multiple gateways by adding entries with any key name. Each gateway requires: - enabled: bool - address: string (REQUIRED) - IP address for the gateway - name: string (optional) - defaults to "<release-name>-<key>" - ipSlot: string (optional) - defaults to key name, used for Cilium LoadBalancerIPPool selector  Example:   gateways:     public:       enabled: true       address: "192.168.1.1"       ipSlot: public     private:       enabled: true       address: "192.168.1.2"       ipSlot: private  |
| httpListenerPolicies | object | {} (empty, user must configure policies) | HTTP listener policies for WebSocket upgrade support. Map structure where keys reference gateway keys from the gateways map. Each policy requires: - enabled: bool - targetGateway: string (REQUIRED) - must match a gateway key - name: string (optional) - defaults to policy key - enabledUpgrades: list of strings (optional) - defaults to ["websocket"]  Example:   httpListenerPolicies:     public-ws:       enabled: true       targetGateway: "public"       enabledUpgrades: ["websocket"]     private-ws:       enabled: true       targetGateway: "private"       enabledUpgrades: ["websocket"]  |
| kgateway-crds.enabled | bool | `true` | Enable installation of kgateway CRDs (required for Gateway API resources) |
| kgateway.enabled | bool | `true` | Enable installation of kgateway controller (required for Gateway functionality) |
| nameOverride | string | "" (uses the chart/release name via the name helper) | Override the base name used in resource naming. This chart uses a simplified naming convention where resources are named "<base-name>-<key>". By default, the base name comes from the chart/release name (for example, "kgateway": kgateway-public, kgateway-private, etc.).  nameOverride is only respected by the kgateway-platform.name helper and can change this base name where that helper is used. It does not affect the kgateway-platform.fullname helper, which currently always derives its value from .Release.Name.  |
| tlsSecret | object | {} (empty map, user must configure) | TLS secret configuration for gateway HTTPS listeners. Specify the secret name and optional namespace.  Example:   tlsSecret:     name: "wildcard-tls"     namespace: "cert-manager"  Note: Cross-namespace secret references require a ReferenceGrant in the secret's namespace (managed by cert-manager-platform chart, not this chart).  |
| trafficPolicies | object | {} (empty, no TrafficPolicies generated) | TrafficPolicies attached to a Gateway. Map structure where keys are policy names and values reference a target gateway. Each entry requires: - enabled: bool - targetGateway: string (REQUIRED) - must match a gateway key - name: string (optional) - defaults to "<release-name>-<key>" - spec: object (optional) - free-form TrafficPolicy.spec body (transformation,         rateLimit, extAuth, etc.). `targetRefs` is auto-filled from         `targetGateway` and any value provided in spec.targetRefs is ignored.  Use case: gateway-wide concerns (security headers, request/response transformations, observability) that should apply to every route attached to a given gateway. For per-route concerns, use kgateway-routing chart instead.  Example — defensive security headers on the public gateway:   trafficPolicies:     public-security-headers:       enabled: true       targetGateway: "public"       spec:         transformation:           response:             set:               - name: Strict-Transport-Security                 value: "max-age=63072000; includeSubDomains; preload"               - name: X-Frame-Options                 value: "DENY"             remove:               - "Server"               - "X-Powered-By"  |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
