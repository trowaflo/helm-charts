{{- define "common.helpers.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "common.helpers.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}


{{- define "common.helpers.namespace" -}}
{{- if .Values.namespaceOverride -}}
{{- .Values.namespaceOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := .Chart.Name -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "common.helpers.labels" -}}
app.kubernetes.io/name: {{ include "common.helpers.name" . }}
helm.sh/chart: {{ include "common.helpers.chart" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "common.helpers.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "common.helpers.imageTag" -}}
{{- if .image.tag -}}
{{ .image.tag }}
{{- else -}}
{{ .Chart.AppVersion }}
{{- end -}}
{{- end -}}

{{- define "common.helpers.resources" -}}
{{- $resources := .resources | default dict -}}
{{ $resources | toYaml }}
{{- end -}}

{{- define "common.helpers.protocol" -}}
{{- $protocol := . | upper -}}
{{- if not (has $protocol (list "TCP" "UDP" "SCTP")) -}}
{{- fail (printf "Invalid protocol: %s. Expected: TCP, UDP, or SCTP." $protocol) -}}
{{- end -}}
{{ $protocol }}
{{- end -}}

{{- define "common.helpers.hasEnabled" -}}
{{- $hasEnabled := false -}}
{{- range $name, $cfg := . -}}
  {{- if and (kindIs "map" $cfg) $cfg.enabled -}}
    {{- $hasEnabled = true -}}
  {{- end -}}
{{- end -}}
{{- if $hasEnabled -}}
true
{{- end -}}
{{- end -}}

{{/*
Generate a resource name from key and config.
Used by PersistentVolume and PersistentVolumeClaim: returns config.name if
provided, otherwise falls back to the map key.
*/}}
{{- define "common.helpers.resourceName" -}}
  {{- $key := .key -}}
  {{- $config := .config -}}
  {{- if $config.name }}
    {{- $config.name }}
  {{- else }}
    {{- $key }}
  {{- end }}
{{- end }}

{{/*
Return the name of the CNPG output "app" secret for a given cluster.
Format: "<release-fullname>-<name>-app". CNPG auto-creates this Secret
alongside the Cluster resource with (at least) these keys: username, password,
uri, pgpass. The full key list depends on the CNPG operator version; confirm
against the running operator before referencing.
Usage: {{ include "common.helpers.cnpgAppSecret" (dict "root" . "name" "postgresql") }}
*/}}
{{- define "common.helpers.cnpgAppSecret" -}}
  {{- $root := required "common.helpers.cnpgAppSecret: root is required" .root -}}
  {{- $name := required "common.helpers.cnpgAppSecret: name is required" .name -}}
  {{- printf "%s-%s-app" (include "common.helpers.fullname" $root) $name -}}
{{- end -}}

{{/*
Return the name of a managed secret.
If secrets.<name>.existingSecret is set, returns that value.
Otherwise returns "<release-fullname>-<name>".
Usage: {{ include "common.helpers.secretName" (dict "root" . "name" "my-secret") }}
*/}}
{{- define "common.helpers.secretName" -}}
  {{- $root := required "common.helpers.secretName: root is required" .root -}}
  {{- $name := required "common.helpers.secretName: name is required" .name -}}
  {{- $secret := index ($root.Values.secrets | default dict) $name | default dict -}}
  {{- if $secret.existingSecret -}}
    {{- $secret.existingSecret -}}
  {{- else -}}
    {{- printf "%s-%s" (include "common.helpers.fullname" $root) $name -}}
  {{- end -}}
{{- end -}}

{{/*
Validate PV configuration - ensure required fields are present
*/}}
{{- define "common.helpers.validatePV" -}}
  {{- $key := .key -}}
  {{- $config := .config -}}
  {{- if not $config.capacity }}
    {{- fail (printf "persistentVolumes.%s: 'capacity' is required" $key) }}
  {{- end }}
  {{- if not $config.accessModes }}
    {{- fail (printf "persistentVolumes.%s: 'accessModes' is required" $key) }}
  {{- end }}
  {{- $hasVolumeSource := false }}
  {{- if or $config.hostPath $config.nfs $config.local $config.iscsi $config.cephfs $config.glusterfs }}
    {{- $hasVolumeSource = true }}
  {{- end }}
  {{- if not $hasVolumeSource }}
    {{- fail (printf "persistentVolumes.%s: at least one volume source (hostPath, nfs, local, iscsi, cephfs, glusterfs) is required" $key) }}
  {{- end }}
{{- end }}

{{/*
Validate PVC configuration - ensure required fields are present
*/}}
{{- define "common.helpers.validatePVC" -}}
  {{- $key := .key -}}
  {{- $config := .config -}}
  {{- if not $config.accessModes }}
    {{- fail (printf "persistentVolumeClaims.%s: 'accessModes' is required" $key) }}
  {{- end }}
  {{- if not $config.resources }}
    {{- fail (printf "persistentVolumeClaims.%s: 'resources' is required" $key) }}
  {{- end }}
  {{- if not $config.resources.requests }}
    {{- fail (printf "persistentVolumeClaims.%s: 'resources.requests' is required" $key) }}
  {{- end }}
  {{- if not $config.resources.requests.storage }}
    {{- fail (printf "persistentVolumeClaims.%s: 'resources.requests.storage' is required" $key) }}
  {{- end }}
{{- end -}}
