{{- define "common.manifests.job" -}}
  {{- range $name, $job := .Values.jobs }}
    {{- if $job.enabled }}
---
apiVersion: batch/v1
kind: Job
metadata:
  name: {{ include "common.helpers.fullname" $ }}-{{ $name }}-{{ now | date "20060102-150405" }}
  namespace: {{ include "common.helpers.namespace" $ }}
  labels:
    {{- include "common.helpers.labels" $ | nindent 4 }}
    app.kubernetes.io/component: {{ $name }}
spec:
  {{- if $job.completions }}
  completions: {{ $job.completions }}
  {{- end }}
  {{- if $job.parallelism }}
  parallelism: {{ $job.parallelism }}
  {{- end }}
  {{- if $job.activeDeadlineSeconds }}
  activeDeadlineSeconds: {{ $job.activeDeadlineSeconds }}
  {{- end }}
  {{- if $job.ttlSecondsAfterFinished }}
  ttlSecondsAfterFinished: {{ $job.ttlSecondsAfterFinished }}
  {{- end }}
  {{- if $job.backoffLimit }}
  backoffLimit: {{ $job.backoffLimit }}
  {{- end }}
  {{- if $job.podFailurePolicy }}
  podFailurePolicy:
    {{- toYaml $job.podFailurePolicy | nindent 4 }}
  {{- end }}
  template:
    metadata:
      labels:
        app.kubernetes.io/name: {{ include "common.helpers.name" $ }}-{{ $name }}
        app.kubernetes.io/instance: {{ $.Release.Name }}
      {{- if $job.podAnnotations }}
      annotations:
        {{- range $key, $value := $job.podAnnotations }}
        {{ $key }}: {{ $value | quote }}
        {{- end }}
      {{- end }}
    spec:
      restartPolicy: {{ $job.restartPolicy | default "OnFailure" }}
      {{- with $job.imagePullSecrets }}
      imagePullSecrets:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- if $job.podSecurityContext }}
      securityContext:
        {{- toYaml $job.podSecurityContext | nindent 8 }}
      {{- end }}
      containers:
        {{- range $containerName, $container := $job.containers }}
        {{- include "common.helpers.container" (dict "root" $ "container" $container "containerName" $containerName) | nindent 8 }}
        {{- end }}
      {{- if $job.volumes }}
      volumes:
        {{- toYaml $job.volumes | nindent 8 }}
      {{- end }}
      {{- with $job.nodeSelector }}
      nodeSelector:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with $job.tolerations }}
      tolerations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
    {{- end }}
  {{- end }}
{{- end -}}
