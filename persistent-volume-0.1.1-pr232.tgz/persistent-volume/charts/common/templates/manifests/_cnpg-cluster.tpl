{{- define "common.manifests.cnpgCluster" -}}
  {{- range $name, $cluster := .Values.cnpgClusters }}
    {{- if $cluster.enabled }}
---
apiVersion: postgresql.cnpg.io/v1
kind: Cluster
metadata:
  name: {{ include "common.helpers.fullname" $ }}-{{ $name }}
  namespace: {{ include "common.helpers.namespace" $ }}
  labels:
    {{- include "common.helpers.labels" $ | nindent 4 }}
    app.kubernetes.io/component: {{ $name }}
spec:
  instances: {{ $cluster.instances | default 1 }}

  imageName: {{ $cluster.imageName }}

  # Storage configuration
  storage:
    {{- if $cluster.storage.storageClass }}
    storageClass: {{ $cluster.storage.storageClass }}
    {{- end }}
    size: {{ $cluster.storage.size }}

  {{- if $cluster.bootstrap }}
  # Bootstrap configuration
  bootstrap:
    {{- if $cluster.bootstrap.initdb }}
    initdb:
      {{- if $cluster.bootstrap.initdb.database }}
      database: {{ $cluster.bootstrap.initdb.database }}
      {{- end }}
      {{- if $cluster.bootstrap.initdb.owner }}
      owner: {{ $cluster.bootstrap.initdb.owner }}
      {{- end }}
      {{- if $cluster.bootstrap.initdb.secret }}
      secret:
        name: {{ $cluster.bootstrap.initdb.secret.name }}
      {{- end }}
    {{- end }}
    {{- if $cluster.bootstrap.recovery }}
    recovery:
      {{- toYaml $cluster.bootstrap.recovery | nindent 6 }}
    {{- end }}
  {{- end }}

  {{- if $cluster.postgresql }}
  # PostgreSQL configuration
  postgresql:
    {{- if $cluster.postgresql.parameters }}
    parameters:
      {{- toYaml $cluster.postgresql.parameters | nindent 6 }}
    {{- end }}
    {{- if $cluster.postgresql.pg_hba }}
    pg_hba:
      {{- toYaml $cluster.postgresql.pg_hba | nindent 6 }}
    {{- end }}
  {{- end }}

  {{- if $cluster.resources }}
  # Resources
  resources:
    {{- toYaml $cluster.resources | nindent 4 }}
  {{- end }}

  {{- if $cluster.monitoring }}
  # Monitoring
  monitoring:
    {{- if $cluster.monitoring.enabled }}
    enablePodMonitor: {{ $cluster.monitoring.podMonitorEnabled | default false }}
    {{- end }}
    {{- if $cluster.monitoring.customQueriesConfigMap }}
    customQueriesConfigMap:
      {{- toYaml $cluster.monitoring.customQueriesConfigMap | nindent 6 }}
    {{- end }}
  {{- end }}

  {{- if $cluster.backup }}
  # Backup configuration
  backup:
    {{- if $cluster.backup.barmanObjectStore }}
    barmanObjectStore:
      {{- toYaml $cluster.backup.barmanObjectStore | nindent 6 }}
    {{- end }}
    {{- if $cluster.backup.retentionPolicy }}
    retentionPolicy: {{ $cluster.backup.retentionPolicy | quote }}
    {{- end }}
    {{- if $cluster.backup.volumeSnapshot }}
    volumeSnapshot:
      {{- toYaml $cluster.backup.volumeSnapshot | nindent 6 }}
    {{- end }}
  {{- end }}

  {{- if $cluster.affinity }}
  # Affinity
  affinity:
    {{- toYaml $cluster.affinity | nindent 4 }}
  {{- end }}

  {{- if $cluster.nodeSelector }}
  # Node selector
  nodeSelector:
    {{- toYaml $cluster.nodeSelector | nindent 4 }}
  {{- end }}

  {{- if $cluster.tolerations }}
  # Tolerations
  tolerations:
    {{- toYaml $cluster.tolerations | nindent 4 }}
  {{- end }}

  {{- if $cluster.replicationSlots }}
  # Replication slots
  replicationSlots:
    {{- toYaml $cluster.replicationSlots | nindent 4 }}
  {{- end }}

  {{- if $cluster.externalClusters }}
  # External clusters
  externalClusters:
    {{- toYaml $cluster.externalClusters | nindent 4 }}
  {{- end }}
    {{- end }}
  {{- end }}
{{- end -}}
