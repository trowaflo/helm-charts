{{- define "common.manifests.statefulset" -}}
  {{- range $name, $statefulset := .Values.statefulsets }}
    {{- if $statefulset.enabled }}
---
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: {{ include "common.helpers.fullname" $ }}-{{ $name }}
  namespace: {{ include "common.helpers.namespace" $ }}
  labels:
    {{- include "common.helpers.labels" $ | nindent 4 }}
    app.kubernetes.io/component: {{ $name }}
spec:
  serviceName: {{ include "common.helpers.fullname" $ }}-{{ $name }}
  replicas: {{ $statefulset.replicas | default 1 }}
  revisionHistoryLimit: {{ $statefulset.revisionHistoryLimit | default 3 }}
  {{- if $statefulset.podManagementPolicy }}
  podManagementPolicy: {{ $statefulset.podManagementPolicy }}
  {{- end }}
  {{- if $statefulset.updateStrategy }}
  updateStrategy:
    {{- toYaml $statefulset.updateStrategy | nindent 4 }}
  {{- end }}
  selector:
    matchLabels:
      app.kubernetes.io/name: {{ include "common.helpers.name" $ }}-{{ $name }}
      app.kubernetes.io/instance: {{ $.Release.Name }}
  template:
    metadata:
      labels:
        app.kubernetes.io/name: {{ include "common.helpers.name" $ }}-{{ $name }}
        app.kubernetes.io/instance: {{ $.Release.Name }}
      {{- if $statefulset.podAnnotations }}
      annotations:
        {{- range $key, $value := $statefulset.podAnnotations }}
        {{ $key }}: {{ $value | quote }}
        {{- end }}
      {{- end }}
    spec:
      automountServiceAccountToken: false
      {{- with $statefulset.imagePullSecrets }}
      imagePullSecrets:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- if $statefulset.podSecurityContext }}
      securityContext:
        {{- toYaml $statefulset.podSecurityContext | nindent 8 }}
      {{- end }}
      {{- if $statefulset.initContainers }}
      initContainers:
        {{- toYaml $statefulset.initContainers | nindent 8 }}
      {{- end }}
      containers:
        {{- range $containerName, $container := $statefulset.containers }}
        {{- include "common.helpers.container" (dict "root" $ "container" $container "containerName" $containerName) | nindent 8 }}
        {{- end }}
      {{- if $statefulset.volumes }}
      volumes:
        {{- toYaml $statefulset.volumes | nindent 8 }}
      {{- end }}
      {{- with $statefulset.nodeSelector }}
      nodeSelector:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with $statefulset.affinity }}
      affinity:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with $statefulset.tolerations }}
      tolerations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
  {{- if $statefulset.volumeClaimTemplates }}
  volumeClaimTemplates:
    {{- toYaml $statefulset.volumeClaimTemplates | nindent 4 }}
  {{- end }}
    {{- end }}
  {{- end }}
{{- end -}}
