{{- define "common.manifests.deployment" -}}
  {{- if .Values.deployment }}
    {{- if .Values.deployment.enabled }}
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ include "common.helpers.fullname" . }}
  namespace: {{ include "common.helpers.namespace" . }}
  labels:
    {{- include "common.helpers.labels" . | nindent 4 }}
spec:
  replicas: {{ .Values.deployment.replicas | default 1 }}
  revisionHistoryLimit: {{ .Values.deployment.revisionHistoryLimit | default 3 }}
  strategy:
    type: {{ .Values.deployment.strategyType | default "RollingUpdate" }}
  selector:
    matchLabels:
      app.kubernetes.io/name: {{ include "common.helpers.name" . }}
      app.kubernetes.io/instance: {{ .Release.Name }}
  template:
    metadata:
      labels:
        app.kubernetes.io/name: {{ include "common.helpers.name" . }}
        app.kubernetes.io/instance: {{ .Release.Name }}
      {{- if .Values.deployment.podAnnotations }}
      annotations:
        {{- range $key, $value := .Values.deployment.podAnnotations }}
        {{ $key }}: {{ $value | quote }}
        {{- end }}
      {{- end }}
    spec:
      automountServiceAccountToken: false
      {{- with .Values.deployment.imagePullSecrets }}
      imagePullSecrets:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- if .Values.deployment.podSecurityContext }}
      securityContext:
        {{- toYaml .Values.deployment.podSecurityContext | nindent 8 }}
      {{- end }}
      {{- if .Values.deployment.initContainers }}
      initContainers:
        {{- toYaml .Values.deployment.initContainers | nindent 8 }}
      {{- end }}
      containers:
        {{- range $containerName, $container := .Values.deployment.containers }}
        {{- include "common.helpers.container" (dict "root" $ "container" $container "containerName" $containerName) | nindent 8 }}
        {{- end }}
      {{- if .Values.deployment.volumes }}
      volumes:
        {{- toYaml .Values.deployment.volumes | nindent 8 }}
      {{- end }}
      {{- with .Values.deployment.nodeSelector }}
      nodeSelector:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with .Values.deployment.affinity }}
      affinity:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with .Values.deployment.tolerations }}
      tolerations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
    {{- end }}
  {{- end }}
{{- end -}}
