{{/*
Expand the name of the chart.
*/}}
{{- define "kgateway-routing.name" -}}
  {{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "kgateway-routing.fullname" -}}
  {{- if .Values.fullnameOverride }}
    {{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
  {{- else }}
    {{- $name := default .Chart.Name .Values.nameOverride }}
    {{- if contains $name .Release.Name }}
      {{- .Release.Name | trunc 63 | trimSuffix "-" }}
    {{- else }}
      {{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
    {{- end }}
  {{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "kgateway-routing.chart" -}}
  {{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "kgateway-routing.labels" -}}
helm.sh/chart: {{ include "kgateway-routing.chart" . }}
{{ include "kgateway-routing.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Chart labels merged with user labels, as a YAML map. A user label wins on a
shared key so an existing selector on it keeps matching.
Usage: {{ include "kgateway-routing.resourceLabels" (dict "root" $ "extra" $cfg.labels) | nindent 4 }}
*/}}
{{- define "kgateway-routing.resourceLabels" -}}
  {{- $chart := include "kgateway-routing.labels" .root | fromYaml -}}
  {{- toYaml (merge (deepCopy (.extra | default dict)) $chart) -}}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "kgateway-routing.selectorLabels" -}}
app.kubernetes.io/name: {{ include "kgateway-routing.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Return the namespace to use
*/}}
{{- define "kgateway-routing.namespace" -}}
  {{- default .Release.Namespace .Values.namespaceOverride }}
{{- end }}

{{/*
Generate route name from key and config
*/}}
{{- define "kgateway-routing.routeName" -}}
  {{- $key := .key -}}
  {{- $config := .config -}}
  {{- $root := .root -}}
  {{- if $config.name }}
    {{- $config.name }}
  {{- else }}
    {{- $key }}
  {{- end }}
{{- end }}

{{/*
Generate backend name from key and config
*/}}
{{- define "kgateway-routing.backendName" -}}
  {{- $key := .key -}}
  {{- $config := .config -}}
  {{- $root := .root -}}
  {{- if $config.name }}
    {{- $config.name }}
  {{- else }}
    {{- printf "%s-backend" $key }}
  {{- end }}
{{- end }}

{{/*
Render a `ResponseHeaderModifier` filter populated with the global
`.Values.defaultSecurityHeaders.set` / `.remove` lists, unless the route
opted out via `securityHeaders: false`.

Returns the filter YAML as a list item starting at column 0 (call with
`| nindent N` to splice into a `filters:` block at the right column), or
empty if the route opted out.

Fails explicitly if the per-route `securityHeaders` field is present but not
a boolean, so typos like `securityHeaders: "true"` (string) or attempts to
inline the map shape at route level are caught at render time.

Usage:
  {{- $sh := include "kgateway-routing.securityHeadersFilter" (dict "root" $ "config" $cfg "key" $key) }}
*/}}
{{- define "kgateway-routing.securityHeadersFilter" -}}
  {{- $cfg := .config -}}
  {{- $key := .key | default "<route>" -}}
  {{- $enabled := true -}}
  {{- if hasKey $cfg "securityHeaders" -}}
    {{- $enabled = $cfg.securityHeaders -}}
    {{- if not (kindIs "bool" $enabled) -}}
      {{- fail (printf "routes.%s.securityHeaders must be a boolean: omit or set `true` to keep them, `false` to opt out. The header list is configured globally at top-level `defaultSecurityHeaders:` (got %s)" $key (kindOf $enabled)) -}}
    {{- end -}}
  {{- end -}}
  {{- if $enabled -}}
    {{- $defaults := .root.Values.defaultSecurityHeaders | default dict -}}
- type: ResponseHeaderModifier
  responseHeaderModifier:
    {{- with $defaults.set }}
    set:
      {{- range . }}
      - name: {{ required "defaultSecurityHeaders.set[].name is required" .name }}
        value: {{ required "defaultSecurityHeaders.set[].value is required" .value | quote }}
      {{- end }}
    {{- end }}
    {{- with $defaults.remove }}
    remove:
      {{- toYaml . | nindent 6 }}
    {{- end }}
  {{- end -}}
{{- end -}}
