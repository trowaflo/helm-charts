# kgateway-routing

![Version: 0.3.0](https://img.shields.io/badge/Version-0.3.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square)

Helm chart for managing Kubernetes Gateway API HTTPRoute and Backend resources.
Supports both in-cluster (Service) and out-of-cluster (Backend) routing with
request/response filters, header modification, and flexible path matching.

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| trowaflo | <trowa.flo@gmail.com> |  |

## Source Code

* <https://github.com/kgateway-dev/kgateway>
* <https://docs.kgateway.dev/>
* <https://github.com/trowaflo/helm-charts>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| defaultForwardAuth | object | {} (no default; `forwardAuth: true` will fail without it) | Default GatewayExtension reference for routes using `forwardAuth: true`. Allows declaring the ExtAuth provider once globally instead of repeating it on every route. Routes can override per-route by setting `forwardAuth: { extensionRef: { name, namespace } }`. |
| defaultParentRefs | list | [] (empty, routes must specify their own parentRefs) | Default parent gateway references for all routes. Applied to routes that don't specify their own `parentRefs`. |
| dnsSuffix | string | "" (empty, no auto-generation) | Global DNS suffix for auto-generating hostnames. When set and a route doesn't have explicit `hostnames`, the hostname will be auto-generated as: `{routeKey}.{dnsSuffix}` Example: With `dnsSuffix: example.com`, route `argocd` gets hostname `argocd.example.com` |
| routes | object | {} (empty, user must configure routes) | HTTP routes configuration. Define multiple routes by adding entries with any key name. Each route can target either in-cluster Services or out-of-cluster Backends.  **Simplified in-cluster Service routing with auto-generated hostname:** ```yaml dnsSuffix: example.com defaultParentRefs:   - name: private-gateway     namespace: kgateway-system routes:   argocd:     enabled: true     # hostname auto-generated as: argocd.example.com     # parentRefs inherited from defaultParentRefs     inCluster:       - name: argocd-server         port: 80 ```  **Simplified out-of-cluster Backend routing:** ```yaml routes:   homeassistant:     enabled: true     hostnames:       - hass.example.com     parentRefs:       - name: public-gateway         namespace: kgateway-system     outCluster:       - name: homeassistant         host: homeassistant.local         port: 8123         filters:           - type: RequestHeaderModifier             requestHeaderModifier:               set:                 - name: X-Forwarded-Proto                   value: https ```  **Backend with TLS policy (for HTTPS backends with self-signed certs):** ```yaml routes:   pmxx:     enabled: true     hostnames:       - pmxx.example.com     parentRefs:       - name: gateway         namespace: kgateway-system     outCluster:       - name: pmxx         host: proxmox1.example.com         port: 8006         tls: true         insecure: true ``` Note: `tls: true` enables TLS with SNI auto-derived from host.       `insecure: true` allows self-signed certificates.  **In-cluster Service with TLS (for HTTPS services with self-signed certs):** ```yaml routes:   internal-api:     enabled: true     hostnames:       - api.example.com     parentRefs:       - name: gateway         namespace: kgateway-system     inCluster:       - name: api-service         port: 8443         tls: true         insecure: true         sni: api-service.namespace.svc.cluster.local ``` Note: For inCluster, `tls: true` creates a Backend CRD and applies BackendConfigPolicy.       SNI defaults to service name but can be overridden with `sni` field.  **Path filtering with `allow:` (default deny):** When `allow` is set on a route, only the listed paths are forwarded to the backend. Anything else returns 404 from the gateway (no rule matches). `/` alone is treated as `Exact` match (root only, not catch-all). Any other path is treated as `PathPrefix`. Without `allow`, the route keeps its current behavior (catch-all `PathPrefix: /`). ```yaml routes:   authentik:     enabled: true     hostnames:       - auth.example.com     allow:       - /                              # Exact: root only       - /if/flow/                      # Prefix: user flows       - /application/o/                # Prefix: OIDC     inCluster:       - name: authentik-server         port: 80 ```  **ForwardAuth via kgateway TrafficPolicy:** When `forwardAuth: true`, a `TrafficPolicy` is generated that attaches an ExtAuth policy to the route, referencing the GatewayExtension declared in `defaultForwardAuth`. Per-route override is also supported. ```yaml defaultForwardAuth:   extensionRef:     name: authentik-extauth     namespace: kgateway routes:   frigate:     enabled: true     hostnames:       - frigate.example.com     forwardAuth: true                  # uses defaultForwardAuth     inCluster:       - name: frigate         port: 8971   custom:     enabled: true     forwardAuth:                       # explicit override       extensionRef:         name: other-extauth         namespace: kgateway     inCluster:       - name: custom-app         port: 80 ```  |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
