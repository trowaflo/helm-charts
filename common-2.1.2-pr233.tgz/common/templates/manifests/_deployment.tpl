{{- define "common.manifests.deployment" -}}
  {{- range $name, $deployment := .Values.deployments }}
    {{- if $deployment.enabled }}
      {{- $_ := required (printf "deployments.%s.containers is required and must define at least one container when enabled" $name) $deployment.containers }}
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ include "common.helpers.fullname" $ }}-{{ $name }}
  namespace: {{ include "common.helpers.namespace" $ }}
  labels:
    {{- include "common.helpers.labels" $ | nindent 4 }}
    app.kubernetes.io/component: {{ $name }}
spec:
  replicas: {{ $deployment.replicas | default 1 }}
  revisionHistoryLimit: {{ $deployment.revisionHistoryLimit | default 3 }}
  strategy:
    type: {{ $deployment.strategyType | default "RollingUpdate" }}
  selector:
    matchLabels:
      app.kubernetes.io/name: {{ include "common.helpers.name" $ }}
      app.kubernetes.io/instance: {{ $.Release.Name }}
      app.kubernetes.io/component: {{ $name }}
  template:
    metadata:
      labels:
        app.kubernetes.io/name: {{ include "common.helpers.name" $ }}
        app.kubernetes.io/instance: {{ $.Release.Name }}
        app.kubernetes.io/component: {{ $name }}
      {{- if $deployment.podAnnotations }}
      annotations:
        {{- range $key, $value := $deployment.podAnnotations }}
        {{ $key }}: {{ $value | quote }}
        {{- end }}
      {{- end }}
    spec:
      {{- with $deployment.serviceAccountName }}
      serviceAccountName: {{ . }}
      {{- end }}
      automountServiceAccountToken: false
      {{- if hasKey $deployment "terminationGracePeriodSeconds" }}
      terminationGracePeriodSeconds: {{ $deployment.terminationGracePeriodSeconds }}
      {{- end }}
      {{- with $deployment.priorityClassName }}
      priorityClassName: {{ . }}
      {{- end }}
      {{- with $deployment.topologySpreadConstraints }}
      topologySpreadConstraints:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with $deployment.imagePullSecrets }}
      imagePullSecrets:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- if $deployment.podSecurityContext }}
      securityContext:
        {{- toYaml $deployment.podSecurityContext | nindent 8 }}
      {{- end }}
      {{- if $deployment.initContainers }}
      initContainers:
        {{- toYaml $deployment.initContainers | nindent 8 }}
      {{- end }}
      containers:
        {{- range $containerName, $container := $deployment.containers }}
        {{- include "common.helpers.container" (dict "root" $ "container" $container "containerName" $containerName) | nindent 8 }}
        {{- end }}
      {{- if $deployment.volumes }}
      volumes:
        {{- toYaml $deployment.volumes | nindent 8 }}
      {{- end }}
      {{- with $deployment.nodeSelector }}
      nodeSelector:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with $deployment.affinity }}
      affinity:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with $deployment.tolerations }}
      tolerations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
    {{- end }}
  {{- end }}
{{- end -}}
