{{- define "common.manifests.statefulset" -}}
  {{- range $name, $statefulset := .Values.statefulsets }}
    {{- if $statefulset.enabled }}
      {{- $_ := required (printf "statefulsets.%s.containers is required and must define at least one container when enabled" $name) $statefulset.containers }}
---
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: {{ include "common.helpers.fullname" $ }}-{{ $name }}
  namespace: {{ include "common.helpers.namespace" $ }}
  labels:
    {{- include "common.helpers.labels" $ | nindent 4 }}
    app.kubernetes.io/component: {{ $name }}
spec:
  serviceName: {{ $statefulset.serviceName | default (printf "%s-%s" (include "common.helpers.fullname" $) $name) }}
  replicas: {{ $statefulset.replicas | default 1 }}
  revisionHistoryLimit: {{ $statefulset.revisionHistoryLimit | default 3 }}
  {{- if $statefulset.podManagementPolicy }}
  podManagementPolicy: {{ $statefulset.podManagementPolicy }}
  {{- end }}
  {{- if $statefulset.updateStrategy }}
  updateStrategy:
    {{- toYaml $statefulset.updateStrategy | nindent 4 }}
  {{- end }}
  selector:
    matchLabels:
      app.kubernetes.io/name: {{ include "common.helpers.name" $ }}
      app.kubernetes.io/instance: {{ $.Release.Name }}
      app.kubernetes.io/component: {{ $name }}
  template:
    metadata:
      labels:
        app.kubernetes.io/name: {{ include "common.helpers.name" $ }}
        app.kubernetes.io/instance: {{ $.Release.Name }}
        app.kubernetes.io/component: {{ $name }}
      {{- if $statefulset.podAnnotations }}
      annotations:
        {{- range $key, $value := $statefulset.podAnnotations }}
        {{ $key }}: {{ $value | quote }}
        {{- end }}
      {{- end }}
    spec:
      automountServiceAccountToken: false
      {{- if hasKey $statefulset "terminationGracePeriodSeconds" }}
      terminationGracePeriodSeconds: {{ $statefulset.terminationGracePeriodSeconds }}
      {{- end }}
      {{- with $statefulset.priorityClassName }}
      priorityClassName: {{ . }}
      {{- end }}
      {{- with $statefulset.topologySpreadConstraints }}
      topologySpreadConstraints:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with $statefulset.imagePullSecrets }}
      imagePullSecrets:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- if $statefulset.podSecurityContext }}
      securityContext:
        {{- toYaml $statefulset.podSecurityContext | nindent 8 }}
      {{- end }}
      {{- if $statefulset.initContainers }}
      initContainers:
        {{- toYaml $statefulset.initContainers | nindent 8 }}
      {{- end }}
      containers:
        {{- range $containerName, $container := $statefulset.containers }}
        {{- include "common.helpers.container" (dict "root" $ "container" $container "containerName" $containerName) | nindent 8 }}
        {{- end }}
      {{- if $statefulset.volumes }}
      volumes:
        {{- toYaml $statefulset.volumes | nindent 8 }}
      {{- end }}
      {{- with $statefulset.nodeSelector }}
      nodeSelector:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with $statefulset.affinity }}
      affinity:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with $statefulset.tolerations }}
      tolerations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
  {{- if $statefulset.volumeClaimTemplates }}
  {{- range $vct := $statefulset.volumeClaimTemplates }}
    {{- $_ := required (printf "statefulsets.%s.volumeClaimTemplates[].metadata.name is required" $name) (($vct.metadata | default dict).name) }}
    {{- $_ := required (printf "statefulsets.%s.volumeClaimTemplates[%s].spec.resources.requests.storage is required" $name $vct.metadata.name) ((((($vct.spec | default dict).resources) | default dict).requests | default dict).storage) }}
  {{- end }}
  volumeClaimTemplates:
    {{- toYaml $statefulset.volumeClaimTemplates | nindent 4 }}
  {{- end }}
  {{- end }}
  {{- end }}
{{- end -}}
