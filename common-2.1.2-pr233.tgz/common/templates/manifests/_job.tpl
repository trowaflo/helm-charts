{{- define "common.manifests.job" -}}
  {{- range $name, $job := .Values.jobs }}
    {{- if $job.enabled }}
      {{- $_ := required (printf "jobs.%s.containers is required and must define at least one container when enabled" $name) $job.containers }}
---
apiVersion: batch/v1
kind: Job
metadata:
  name: {{ include "common.helpers.fullname" $ }}-{{ $name }}
  namespace: {{ include "common.helpers.namespace" $ }}
  labels:
    {{- include "common.helpers.labels" $ | nindent 4 }}
    app.kubernetes.io/component: {{ $name }}
spec:
  {{- if hasKey $job "completions" }}
  completions: {{ $job.completions }}
  {{- end }}
  {{- if hasKey $job "parallelism" }}
  parallelism: {{ $job.parallelism }}
  {{- end }}
  {{- if hasKey $job "activeDeadlineSeconds" }}
  activeDeadlineSeconds: {{ $job.activeDeadlineSeconds }}
  {{- end }}
  {{- if hasKey $job "ttlSecondsAfterFinished" }}
  ttlSecondsAfterFinished: {{ $job.ttlSecondsAfterFinished }}
  {{- end }}
  {{- if hasKey $job "backoffLimit" }}
  backoffLimit: {{ $job.backoffLimit }}
  {{- end }}
  {{- if $job.podFailurePolicy }}
  podFailurePolicy:
    {{- toYaml $job.podFailurePolicy | nindent 4 }}
  {{- end }}
  template:
    metadata:
      labels:
        app.kubernetes.io/name: {{ include "common.helpers.name" $ }}
        app.kubernetes.io/instance: {{ $.Release.Name }}
        app.kubernetes.io/component: {{ $name }}
      {{- if $job.podAnnotations }}
      annotations:
        {{- range $key, $value := $job.podAnnotations }}
        {{ $key }}: {{ $value | quote }}
        {{- end }}
      {{- end }}
    spec:
      restartPolicy: {{ $job.restartPolicy | default "OnFailure" }}
      {{- with $job.serviceAccountName }}
      serviceAccountName: {{ . }}
      {{- end }}
      automountServiceAccountToken: false
      {{- if hasKey $job "terminationGracePeriodSeconds" }}
      terminationGracePeriodSeconds: {{ $job.terminationGracePeriodSeconds }}
      {{- end }}
      {{- with $job.priorityClassName }}
      priorityClassName: {{ . }}
      {{- end }}
      {{- with $job.topologySpreadConstraints }}
      topologySpreadConstraints:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with $job.imagePullSecrets }}
      imagePullSecrets:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- if $job.podSecurityContext }}
      securityContext:
        {{- toYaml $job.podSecurityContext | nindent 8 }}
      {{- end }}
      {{- if $job.initContainers }}
      initContainers:
        {{- toYaml $job.initContainers | nindent 8 }}
      {{- end }}
      containers:
        {{- range $containerName, $container := $job.containers }}
        {{- include "common.helpers.container" (dict "root" $ "container" $container "containerName" $containerName) | nindent 8 }}
        {{- end }}
      {{- if $job.volumes }}
      volumes:
        {{- toYaml $job.volumes | nindent 8 }}
      {{- end }}
      {{- with $job.nodeSelector }}
      nodeSelector:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with $job.affinity }}
      affinity:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with $job.tolerations }}
      tolerations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
    {{- end }}
  {{- end }}
{{- end -}}
