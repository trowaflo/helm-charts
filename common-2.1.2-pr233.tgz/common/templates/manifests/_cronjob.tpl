{{- define "common.manifests.cronjob" -}}
  {{- range $name, $cronjob := .Values.cronjobs }}
    {{- if $cronjob.enabled }}
      {{- $_ := required (printf "cronjobs.%s.containers is required and must define at least one container when enabled" $name) $cronjob.containers }}
---
apiVersion: batch/v1
kind: CronJob
metadata:
  name: {{ include "common.helpers.fullname" $ }}-{{ $name }}
  namespace: {{ include "common.helpers.namespace" $ }}
  labels:
    {{- include "common.helpers.labels" $ | nindent 4 }}
    app.kubernetes.io/component: {{ $name }}
spec:
  schedule: {{ $cronjob.schedule | quote }}
  {{- if $cronjob.timeZone }}
  timeZone: {{ $cronjob.timeZone | quote }}
  {{- end }}
  {{- if hasKey $cronjob "suspend" }}
  suspend: {{ $cronjob.suspend }}
  {{- end }}
  {{- if hasKey $cronjob "successfulJobsHistoryLimit" }}
  successfulJobsHistoryLimit: {{ $cronjob.successfulJobsHistoryLimit }}
  {{- else }}
  successfulJobsHistoryLimit: 3
  {{- end }}
  {{- if hasKey $cronjob "failedJobsHistoryLimit" }}
  failedJobsHistoryLimit: {{ $cronjob.failedJobsHistoryLimit }}
  {{- else }}
  failedJobsHistoryLimit: 3
  {{- end }}
  concurrencyPolicy: {{ $cronjob.concurrencyPolicy | default "Forbid" }}
  {{- if hasKey $cronjob "startingDeadlineSeconds" }}
  startingDeadlineSeconds: {{ $cronjob.startingDeadlineSeconds }}
  {{- end }}
  jobTemplate:
    spec:
      {{- if hasKey $cronjob "ttlSecondsAfterFinished" }}
      ttlSecondsAfterFinished: {{ $cronjob.ttlSecondsAfterFinished }}
      {{- end }}
      template:
        metadata:
          labels:
            app.kubernetes.io/name: {{ include "common.helpers.name" $ }}
            app.kubernetes.io/instance: {{ $.Release.Name }}
            app.kubernetes.io/component: {{ $name }}
          {{- if $cronjob.podAnnotations }}
          annotations:
            {{- range $key, $value := $cronjob.podAnnotations }}
            {{ $key }}: {{ $value | quote }}
            {{- end }}
          {{- end }}
        spec:
          restartPolicy: {{ $cronjob.restartPolicy | default "OnFailure" }}
          automountServiceAccountToken: false
          {{- with $cronjob.imagePullSecrets }}
          imagePullSecrets:
            {{- toYaml . | nindent 12 }}
          {{- end }}
          {{- if $cronjob.podSecurityContext }}
          securityContext:
            {{- toYaml $cronjob.podSecurityContext | nindent 12 }}
          {{- end }}
          containers:
            {{- range $containerName, $container := $cronjob.containers }}
            {{- include "common.helpers.container" (dict "root" $ "container" $container "containerName" $containerName) | nindent 12 }}
            {{- end }}
          {{- if $cronjob.volumes }}
          volumes:
            {{- toYaml $cronjob.volumes | nindent 12 }}
          {{- end }}
          {{- with $cronjob.nodeSelector }}
          nodeSelector:
            {{- toYaml . | nindent 12 }}
          {{- end }}
          {{- with $cronjob.affinity }}
          affinity:
            {{- toYaml . | nindent 12 }}
          {{- end }}
          {{- with $cronjob.tolerations }}
          tolerations:
            {{- toYaml . | nindent 12 }}
          {{- end }}
    {{- end }}
  {{- end }}
{{- end -}}
